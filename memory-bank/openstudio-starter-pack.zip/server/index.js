import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';

const PORT = process.env.PORT || 8080;
const wss = new WebSocketServer({ port: PORT });

/**
 * Minimal signaling server:
 * - Rooms keyed by roomId
 * - Roles: host | caller
 * - Messages: join, offer, answer, ice, mute, unmute, promote, demote
 */
const rooms = new Map();

function getRoom(id) {
  if (!rooms.has(id)) rooms.set(id, { peers: new Map() });
  return rooms.get(id);
}

wss.on('connection', (ws) => {
  const peerId = uuidv4();
  let roomId = null;

  ws.on('message', (raw) => {
    try {
      const msg = JSON.parse(raw.toString());
      if (msg.type === 'join') {
        roomId = msg.roomId;
        const role = msg.role || 'caller';
        const room = getRoom(roomId);
        room.peers.set(peerId, { ws, role });
        // notify others
        room.peers.forEach((p, id) => {
          if (id !== peerId) p.ws.send(JSON.stringify({ type: 'peer-joined', peerId, role }));
        });
        ws.send(JSON.stringify({ type: 'joined', peerId }));
      } else if (['offer','answer','ice','control'].includes(msg.type)) {
        const room = getRoom(roomId);
        const { to } = msg;
        if (to && room.peers.has(to)) {
          room.peers.get(to).ws.send(JSON.stringify({ ...msg, from: peerId }));
        } else {
          // broadcast to all others
          room.peers.forEach((p, id) => {
            if (id !== peerId) p.ws.send(JSON.stringify({ ...msg, from: peerId }));
          });
        }
      }
    } catch (e) {
      console.error('Bad message', e);
    }
  });

  ws.on('close', () => {
    if (!roomId) return;
    const room = getRoom(roomId);
    room.peers.delete(peerId);
    room.peers.forEach((p) => p.ws.send(JSON.stringify({ type: 'peer-left', peerId })));
  });
});

console.log(`OpenStudio signaling listening on :${PORT}`);
