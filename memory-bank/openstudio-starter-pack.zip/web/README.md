# OpenStudio Web (scaffold)

This is a placeholder for the Studio UI. Target stack: SvelteKit or React + Vite.
Features to implement:
- Device selection (mic/speakers)
- Host/Caller roles
- Per‑participant meters + mute
- Mix‑minus buses
- Icecast encoder (OGG/Opus via MediaRecorder)
- Directory lookup (DHT/libp2p)

For now, this folder only documents the intended UI surface.
